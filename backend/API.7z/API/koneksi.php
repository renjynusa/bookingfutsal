<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "sman5semarang";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
?>