<?php
$adminemail = "gssshop07@gmail.com";
$adminpass = "Indonesia-hebat";
?>