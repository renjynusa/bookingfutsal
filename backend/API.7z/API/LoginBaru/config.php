<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "sman5semarang";

$conn = mysqli_connect($host,$user,$pass,$db);
	// if($conn){
	// 	echo "Connection Estabilished";
	// }else{
	// 	echo "Connection error";
	// }


?>